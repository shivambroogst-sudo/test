// ================================================
// java-versions.js
// ================================================
// Picks the right Java runtime for a given Minecraft version, the same way
// Pterodactyl's official eggs do, and locates it among the multiple JDKs
// installed by install-panel.sh / install-daemon.sh (under /opt/java/<major>).

const fs = require('fs');
const path = require('path');

const JAVA_INSTALL_DIR = process.env.JAVA_INSTALL_DIR || '/opt/java';

// Which Java major version a given Minecraft version needs to run.
function recommendedJavaMajor(mcVersion) {
    if (!mcVersion || mcVersion === 'latest') return 21;
    const parts = String(mcVersion).split('.').map(n => parseInt(n, 10));
    const major = parts[0];
    const minor = parts[1] || 0;
    const patch = parts[2] || 0;

    if (major !== 1) return 21; // modded / non-standard version string - safe modern default

    if (minor <= 16) return 8;          // 1.0 - 1.16.5
    if (minor === 17) return 17;        // 1.17 - 1.17.1
    if (minor < 20 || (minor === 20 && patch < 5)) return 17; // 1.18 - 1.20.4
    return 21;                          // 1.20.5+
}

// Find an installed JDK's java binary for the requested major version,
// falling back to the closest one actually installed, and finally to
// whatever "java" resolves to on PATH.
function getJavaBinary(major) {
    const isWin = process.platform === 'win32';
    const bin = isWin ? 'java.exe' : 'java';

    const tryMajor = (m) => {
        const p = path.join(JAVA_INSTALL_DIR, String(m), 'bin', bin);
        return fs.existsSync(p) ? p : null;
    };

    let found = tryMajor(major);
    if (found) return found;

    // Prefer the closest higher version (newer JVMs run older bytecode fine)
    for (const m of [8, 11, 16, 17, 21, 25]) {
        if (m >= major) {
            found = tryMajor(m);
            if (found) return found;
        }
    }
    // Then just take whatever is installed at all
    for (const m of [21, 17, 25, 16, 11, 8]) {
        found = tryMajor(m);
        if (found) return found;
    }

    return bin; // last resort: rely on system PATH
}

function listInstalledJavaVersions() {
    if (!fs.existsSync(JAVA_INSTALL_DIR)) return [];
    return fs.readdirSync(JAVA_INSTALL_DIR).filter(name => {
        const bin = path.join(JAVA_INSTALL_DIR, name, 'bin', process.platform === 'win32' ? 'java.exe' : 'java');
        return fs.existsSync(bin);
    });
}

module.exports = { recommendedJavaMajor, getJavaBinary, listInstalledJavaVersions, JAVA_INSTALL_DIR };
