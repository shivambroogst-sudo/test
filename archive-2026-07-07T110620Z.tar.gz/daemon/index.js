// ================================================
// OGhost Daemon
// ================================================
// Runs on EACH VPS/node. The panel (app.js) connects to this over
// Socket.io and tells it to create/start/stop/command Minecraft servers.
// This process is the one that actually calls child_process.spawn - the
// panel itself never touches java on a remote node directly.

require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const pidusage = require('pidusage');
const sanitize = require('sanitize-filename');

const PORT = parseInt(process.env.PORT || '8443', 10);
const TOKEN = process.env.DAEMON_TOKEN;
const SERVERS_DIR = path.resolve(process.env.SERVERS_DIR || './servers');
const JAVA_PATH = process.env.JAVA_PATH || 'java';

if (!TOKEN) {
    console.error('DAEMON_TOKEN is not set. Copy .env.example to .env and set a secret token.');
    process.exit(1);
}

if (!fs.existsSync(SERVERS_DIR)) fs.mkdirSync(SERVERS_DIR, { recursive: true });

const app = express();
app.get('/health', (req, res) => res.json({ ok: true, servers: Object.keys(processes).length }));
const httpServer = http.createServer(app);
const io = new Server(httpServer, { cors: { origin: '*' } });

// serverId -> child process
const processes = {};
// serverId -> Date.now() when it was started (for crash-loop detection)
const startTimes = {};

// ---- Auth: every connecting socket (i.e. the panel) must present the ----
// ---- shared DAEMON_TOKEN configured in .env / the panel's node form. ----
io.use((socket, next) => {
    const token = socket.handshake.auth && socket.handshake.auth.token;
    if (token === TOKEN) return next();
    next(new Error('unauthorized'));
});

function serverDir(serverId) {
    return path.join(SERVERS_DIR, String(serverId));
}

function broadcastConsole(serverId, line) {
    io.emit('console', { serverId, line });
}

function broadcastStatus(serverId, status, error) {
    io.emit('serverStatus', { serverId, status, error });
}

function reply(socket, requestId, ok, data, error) {
    socket.emit('response', { requestId, ok, data, error });
}

// ---- Minimal jar downloader (most common server types). Extend the ------
// ---- switch below if you need spigot/forge/bedrock/etc on this node. ----
async function downloadServerJar(serverType, version, dir) {
    let url;
    let actualVersion = version;

    const FILL_HEADERS = { 'User-Agent': 'OGhost-Panel-Daemon/1.0 (+https://github.com/oghost-panel)' };

    if (serverType === 'vanilla') {
        const manifestRes = await axios.get('https://launchermeta.mojang.com/mc/game/version_manifest.json');
        if (version === 'latest') actualVersion = manifestRes.data.latest.release;
        const ver = manifestRes.data.versions.find(v => v.id === actualVersion);
        if (!ver) throw new Error(`Vanilla version ${actualVersion} not found`);
        const verJsonRes = await axios.get(ver.url);
        url = verJsonRes.data.downloads.server.url;
    } else if (serverType === 'paper') {
        // PaperMC's old v2 API (api.papermc.io) was fully disabled on
        // July 1, 2026. Everything now goes through the new Fill v3 API.
        if (version === 'latest') {
            const projRes = await axios.get('https://fill.papermc.io/v3/projects/paper', { headers: FILL_HEADERS });
            const groups = Object.values(projRes.data.versions);
            actualVersion = groups[0][0];
        }
        const buildsRes = await axios.get(`https://fill.papermc.io/v3/projects/paper/versions/${actualVersion}/builds`, { headers: FILL_HEADERS });
        const builds = buildsRes.data;
        const build = builds.find(b => b.channel === 'STABLE') || builds[0];
        if (!build || !build.downloads || !build.downloads['server:default']) {
            throw new Error(`No Paper build found for version ${actualVersion}`);
        }
        url = build.downloads['server:default'].url;
    } else if (serverType === 'purpur') {
        if (version === 'latest') {
            const res = await axios.get('https://api.purpurmc.org/v2/purpur');
            actualVersion = res.data.versions[res.data.versions.length - 1];
        }
        const latestBuildRes = await axios.get(`https://api.purpurmc.org/v2/purpur/${actualVersion}/latest`);
        url = `https://api.purpurmc.org/v2/purpur/${actualVersion}/${latestBuildRes.data.build}/download`;
    } else if (serverType === 'fabric') {
        const loaderRes = await axios.get('https://meta.fabricmc.net/v2/versions/loader');
        const loader = loaderRes.data[0].version;
        url = `https://meta.fabricmc.net/v2/versions/loader/${actualVersion}/${loader}/server/jar`;
    } else {
        throw new Error(`Server type "${serverType}" is not supported by this daemon build yet`);
    }

    const jarPath = path.join(dir, 'server.jar');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    const response = await axios({ url, method: 'GET', responseType: 'stream', timeout: 300000 });
    const writer = fs.createWriteStream(jarPath);
    response.data.pipe(writer);

    await new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
    });

    return actualVersion;
}

// ---- Socket.io handlers ---------------------------------------------------
io.on('connection', (socket) => {
    console.log(`[daemon] Panel connected (${socket.id})`);

    socket.on('node:ping', ({ requestId }) => {
        reply(socket, requestId, true, { pong: true, time: Date.now(), running: Object.keys(processes).length });
    });

    // Create the server's directory + accept eula + download jar
    socket.on('server:create', async ({ requestId, server }) => {
        try {
            const id = server.id;
            const dir = serverDir(id);
            fs.mkdirSync(dir, { recursive: true });
            fs.writeFileSync(path.join(dir, 'eula.txt'), 'eula=true\n');

            const props = server.serverProperties || {};
            props['server-port'] = server.port;
            const propLines = Object.entries(props).map(([k, v]) => `${k}=${v}`).join('\n');
            fs.writeFileSync(path.join(dir, 'server.properties'), propLines + '\n');

            const actualVersion = await downloadServerJar(server.serverType, server.version, dir);
            reply(socket, requestId, true, { dir, actualVersion });
        } catch (err) {
            reply(socket, requestId, false, null, err.message);
        }
    });

    // Start (or resume) a server process
    socket.on('server:start', async ({ requestId, serverId }) => {
        try {
            if (processes[serverId]) {
                return reply(socket, requestId, false, null, 'Server is already running on this node');
            }
            const dir = serverDir(serverId);
            if (!fs.existsSync(path.join(dir, 'server.jar'))) {
                return reply(socket, requestId, false, null, 'server.jar not found - create the server first');
            }

            const metaPath = path.join(dir, '.oghost-meta.json');
            const meta = fs.existsSync(metaPath) ? JSON.parse(fs.readFileSync(metaPath, 'utf8')) : { ram: 1024 };
            const xms = Math.max(256, Math.floor(meta.ram / 4));
            const javaArgs = ['-Xms' + xms + 'M', '-Xmx' + meta.ram + 'M', '-jar', 'server.jar', 'nogui'];

            const proc = spawn(JAVA_PATH, javaArgs, { cwd: dir, stdio: ['pipe', 'pipe', 'pipe'] });
            processes[serverId] = proc;
            startTimes[serverId] = Date.now();

            proc.stdout.on('data', (data) => broadcastConsole(serverId, data.toString()));
            proc.stderr.on('data', (data) => broadcastConsole(serverId, data.toString()));

            proc.on('exit', (code, signal) => {
                delete processes[serverId];
                const uptime = Date.now() - (startTimes[serverId] || Date.now());
                delete startTimes[serverId];
                broadcastStatus(serverId, 'stopped', code !== 0 && uptime < 10000 ? 'Crashed immediately after start' : null);
            });

            broadcastStatus(serverId, 'running', null);
            reply(socket, requestId, true, { pid: proc.pid });
        } catch (err) {
            reply(socket, requestId, false, null, err.message);
        }
    });

    // Graceful (or forced) stop
    socket.on('server:stop', ({ requestId, serverId, force }) => {
        const proc = processes[serverId];
        if (!proc) return reply(socket, requestId, false, null, 'Server is not running on this node');
        try {
            if (force) {
                proc.kill('SIGKILL');
            } else {
                proc.stdin.write('stop\n');
                setTimeout(() => {
                    if (processes[serverId]) proc.kill('SIGTERM');
                }, 30000);
            }
            reply(socket, requestId, true, { stopping: true });
        } catch (err) {
            reply(socket, requestId, false, null, err.message);
        }
    });

    // Send a console command (write to stdin)
    socket.on('server:command', ({ requestId, serverId, command }) => {
        const proc = processes[serverId];
        if (!proc) return reply(socket, requestId, false, null, 'Server is not running on this node');
        try {
            proc.stdin.write(command + '\n');
            reply(socket, requestId, true, { sent: true });
        } catch (err) {
            reply(socket, requestId, false, null, err.message);
        }
    });

    // Delete a server entirely (kill process + remove files)
    socket.on('server:delete', ({ requestId, serverId }) => {
        try {
            const proc = processes[serverId];
            if (proc) proc.kill('SIGKILL');
            delete processes[serverId];
            const dir = serverDir(serverId);
            fs.rmSync(dir, { recursive: true, force: true });
            reply(socket, requestId, true, { deleted: true });
        } catch (err) {
            reply(socket, requestId, false, null, err.message);
        }
    });

    // On-demand CPU/RAM stats for one server
    socket.on('server:stats', async ({ requestId, serverId }) => {
        const proc = processes[serverId];
        if (!proc) return reply(socket, requestId, true, { status: 'stopped' });
        try {
            const stats = await pidusage(proc.pid);
            reply(socket, requestId, true, { status: 'running', cpu: stats.cpu, memory: stats.memory });
        } catch (err) {
            reply(socket, requestId, false, null, err.message);
        }
    });

    socket.on('disconnect', () => {
        console.log(`[daemon] Panel disconnected (${socket.id})`);
    });
});

// Push stats for every running server every 5s so the panel can show
// live graphs without polling.
setInterval(async () => {
    for (const [serverId, proc] of Object.entries(processes)) {
        try {
            const stats = await pidusage(proc.pid);
            io.emit('stats', { serverId, stats: { cpu: stats.cpu, memory: stats.memory } });
        } catch (err) {
            // process probably just exited between the loop tick and here
        }
    }
}, 5000);

httpServer.listen(PORT, () => {
    console.log(`OGhost daemon listening on port ${PORT}`);
    console.log(`Servers directory: ${SERVERS_DIR}`);
});
